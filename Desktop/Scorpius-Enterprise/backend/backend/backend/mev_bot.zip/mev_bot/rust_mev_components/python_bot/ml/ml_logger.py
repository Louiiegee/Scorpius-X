
# ml_logger.py

def log_ml_prediction(opportunity, confidence):
    print(f"[ML] 🤖 Predicted opportunity {opportunity} with confidence {confidence:.2f}")
