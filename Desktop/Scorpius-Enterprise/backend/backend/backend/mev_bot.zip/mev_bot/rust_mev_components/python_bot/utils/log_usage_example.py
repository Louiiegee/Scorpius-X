
# Example call after opportunity found:
log_arbitrage_opportunity("DAI/WETH", 47, 0.8)
