"""Authentication endpoints for Scorpius X."""
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
import time

router = APIRouter(prefix="/auth", tags=["Authentication"])

# Hardcoded credentials for demonstration
# In production, use a secure database with hashed passwords
VALID_USERS = {
    "admin@scorpiusx.io": {
        "password": "scorpius123",
        "role": "admin",
        "name": "Admin",
        "avatar": "🦂"
    }
}

class LoginRequest(BaseModel):
    email: str
    password: str

class User(BaseModel):
    email: str
    role: str
    name: str
    avatar: str
    token: str

@router.post("/login")
async def login(request: LoginRequest):
    """Authenticate a user."""
    if request.email not in VALID_USERS:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    user_data = VALID_USERS[request.email]
    if request.password != user_data["password"]:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Generate a simple token (use JWT in production)
    token = f"{request.email}:{int(time.time())}"
    
    return {
        "success": True,
        "user": {
            "email": request.email,
            "role": user_data["role"],
            "name": user_data["name"],
            "avatar": user_data["avatar"],
            "token": token
        }
    }

@router.get("/me")
async def get_current_user(token: Optional[str] = None):
    """Get current user from token."""
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    # Parse the simple token
    try:
        email, _ = token.split(":", 1)
        if email not in VALID_USERS:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        user_data = VALID_USERS[email]
        return {
            "email": email,
            "role": user_data["role"],
            "name": user_data["name"],
            "avatar": user_data["avatar"]
        }
    except:
        raise HTTPException(status_code=401, detail="Invalid token")
